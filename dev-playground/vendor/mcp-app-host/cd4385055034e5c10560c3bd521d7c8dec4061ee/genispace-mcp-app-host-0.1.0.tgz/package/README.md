# Geni MCP Apps Host

Private shared host for platform Chat, Embed and Geni Desktop. The core uses
MCP SDK 1.29.0 and MCP Apps 1.7.5. React is an optional peer (18.3.1 or 19).

`/core` exposes `createAppHost`, host-owned descriptors, size and scope policies.
`/react` exposes `McpAppView`; retain the same mounted frame when changing Tabs
or entering fullscreen. `/sandbox` exports the immutable proxy HTML, manifest,
hash and response-CSP builder. The untrusted inner frame always has an opaque
origin (`sandbox="allow-scripts"`). Serve the trusted proxy on a separate origin.

Credentials belong exclusively to the `HostPort`. It implements resource reads,
fresh tool discovery, per-action authorization, cancellation and closing. A view
has no complete MCP client, credential, arbitrary fetch or native-command handle.
Tool interaction is disabled until the host enables it. Sampling is not exposed.
Model-context updates never create a model request.

Build and test with `pnpm --filter @genispace/mcp-app-host build` and
`pnpm --filter @genispace/mcp-app-host test:coverage`. The protocol tests use the
official `App` and `AppBridge`; real browser/native sandbox checks are separate.

To export an immutable built artifact, commit the Host source and lock, then run
`node packages/mcp-app-host/scripts/export-git-release.mjs --artifact-only`.
The archive includes SOURCE.json and a separate release.json records its exact
SHA-256, npm integrity and proxy hash. Consumers vendor this identical archive;
their clean-checkout CI needs no private repository or npm publishing credential.
Do not copy or edit Host source in consumers. A new build receives a new source
commit and archive. The script can also fast-forward a package-root Git release
branch for provenance, without switching the checkout or pushing. `--check`
verifies the packed allowlist without writing a ref. This repository and package
are private; never publish their source or artifacts to a public registry.

Default limits: HTML 8 MiB, result 4 MiB, wire message 20 MiB (JSON overhead),
future context 64 KiB; initialization/resource timeout 15 seconds. Oversize data
is rejected, never truncated. These are host ceilings, not resource permissions.
